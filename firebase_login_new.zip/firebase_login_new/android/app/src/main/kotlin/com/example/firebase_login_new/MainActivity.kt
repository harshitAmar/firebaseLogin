package com.example.firebase_login_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
